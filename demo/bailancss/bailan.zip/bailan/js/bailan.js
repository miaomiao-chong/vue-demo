window.onload = function a123() {
	var a1 = document.getElementById("a1");
	var a2 = document.getElementById("a2");
	var a3 = document.getElementById("a3");
	var b1 = document.getElementById("b1");
	var b2 = document.getElementById("b2");

	var c1 = document.getElementById("c1");
	var c2 = document.getElementById("c2");
	var c11 = document.getElementById("c11");
	var c22 = document.getElementById("c22");
	var c111 = document.getElementById("c111");
	var c222 = document.getElementById("c222");

	var czuo1 = document.getElementById("czuo1");
	var cyou2 = document.getElementById("cyou2");
	var czhong3 = document.getElementById("czhong3");

	var white = document.getElementById("zhezhao");
	var white2 = document.getElementById("zhezhao2");
	var white3 = document.getElementById("zhezhao3");

	var d1 = document.getElementById("d1");
	var d2 = document.getElementById("d2");

	var f1 = document.getElementById("dzuo1");
	var f2 = document.getElementById("dzuo2");
	var f3 = document.getElementById("dyou1");
	var f4 = document.getElementById("dyou2");

	var overf = document.getElementById("overf");

	var wzz = document.getElementById("wzz");

	var wz1 = document.getElementById("wz1");
	var wz2 = document.getElementById("wz2");
	var wz3 = document.getElementById("wz3");
	var wz4 = document.getElementById("wz4");
	var wz5 = document.getElementById("wz5");
	var wz6 = document.getElementById("wz6");
	var wz7 = document.getElementById("wz7");

	var a123 = document.querySelector(".a123");
	var wzz2 = document.querySelector(".wzz2");
	setTimeout(
		function aa1() {
			a1.style.opacity = "1";
		}, 1000);
	setTimeout(
		function aa2() {
			a2.style.opacity = "1";
		}, 1750);
	setTimeout(
		function aa3() {
			a3.style.opacity = "1";
		}, 2500);
	setTimeout(
		function aa123() {
			a1.style.width = "300px";
			a2.style.opacity = "0";
			a3.style.opacity = "0";
		}, 3250);

	setTimeout(
		function aaa1() {
			a1.style.marginTop = "100px";
			a1.style.width = "500px";
		}, 3700);

	setTimeout(
		function bb1() {
			a1.style.display = "none";
			b1.style.opacity = "1";
			b2.style.opacity = "1";
		}, 4300);

	setTimeout(
		function bb2() {
			a1.style.display = "inline";
			b1.style.opacity = "0";
			b2.style.opacity = "0";
		}, 4800);

	setTimeout(
		function bb3() {
			a1.style.transform = "rotate(180deg)";
		}, 5500);

	setTimeout(
		function bb4() {
			a1.style.animation = "xz1 1.5s linear";
		}, 6000);

	setTimeout(
		function bb5() {
			a1.style.display = "none";
			b1.style.opacity = "1";
			b2.style.opacity = "1";
			b1.style.animation = "xz1 2s linear";
			b2.style.animation = "xz1 2s linear";
		}, 7500);

	setTimeout(
		function cc1() {
			b1.style.opacity = "0";
			b2.style.opacity = "0";
			czuo1.style.opacity = "1";
			c2.style.animation = "hs 1s linear";
			white.style.animation = "bpxs 1s linear";
		}, 9500);


	setTimeout(
		function cc2() {
			cyou2.style.opacity = "1";
			c22.style.animation = "hs 1s linear";
			white2.style.animation = "bpxs 1s linear";
		}, 10000);

	setTimeout(
		function cc3() {
			czhong3.style.opacity = "1";
			c222.style.animation = "hs 1s linear";
			white3.style.animation = "bpxs 1s linear";
			czuo1.style.opacity = "0";
		}, 10500);


	setTimeout(
		function cc4() {
			cyou2.style.opacity = "0";
		}, 11000);


	setTimeout(
		function cc5() {
			czhong3.style.opacity = "0";
			d1.style.opacity = "1";
			d1.style.animation = "dl1 3.5s linear";
		}, 11500);

	setTimeout(
		function dd1() {
			d1.style.opacity = "0";
			d2.style.opacity = "1";
			d2.style.animation = "dl2 3.5s linear";
		}, 15000);


	setTimeout(
		function dd2() {
			d2.style.animation = "dl3 3.5s linear";
		}, 18000);


	setTimeout(
		function dd3() {
			d2.style.animation = "dl4 3s linear";
		}, 21500);

	setTimeout(
		function ee1() {
			czuo1.style.opacity = "1";
			czuo1.style.top = "100px";
			czuo1.style.left = "100px";
			c2.style.animation = "hs2 1s linear";
			white.style.animation = "bpxs2 1s linear";
		}, 22500);


	setTimeout(
		function ee2() {
			cyou2.style.opacity = "1";
			cyou2.style.top = "300px";
			cyou2.style.left = "500px";
			c22.style.animation = "hs2 1s linear";
			white2.style.animation = "bpxs2 1s linear";
		}, 23000);

	setTimeout(
		function ee3() {
			czuo1.style.opacity = "0";
			czhong3.style.opacity = "1";
			czhong3.style.top = "100px";
			czhong3.style.left = "800px";
			c222.style.animation = "hs2 1s linear";
			white3.style.animation = "bpxs2 1s linear";
		}, 23500);

	setTimeout(
		function ee4() {
			cyou2.style.opacity = "0";
			czuo1.style.opacity = "1";
			czuo1.style.top = "300px";
			czuo1.style.left = "1200px";
			c2.style.animation = "hs 1s linear";
			white.style.animation = "bpxs 1s linear";
		}, 24000);


	setTimeout(
		function ee5() {
			cyou2.style.opacity = "1";
			cyou2.style.top = "0px";
			cyou2.style.left = "200px";
			c22.style.animation = "hs 1s linear";
			white2.style.animation = "bpxs 1s linear";
			czhong3.style.opacity = "0";
		}, 24500);


	setTimeout(
		function ee6() {
			czhong3.style.opacity = "1";
			czhong3.style.top = "100px";
			czhong3.style.left = "400px";
			c222.style.animation = "hs 1s linear";
			white3.style.animation = "bpxs 1s linear";
			czuo1.style.opacity = "0";
		}, 25000);


	setTimeout(
		function ee7() {
			czuo1.style.opacity = "1";
			czuo1.style.top = "0px";
			czuo1.style.left = "800px";
			c2.style.animation = "hs2 1s linear";
			white.style.animation = "bpxs2 1s linear";
			cyou2.style.opacity = "0";
		}, 25500);

	setTimeout(
		function ee8() {
			cyou2.style.opacity = "1";
			cyou2.style.top = "200px";
			cyou2.style.left = "1200px";
			c22.style.animation = "hs2 1s linear";
			white2.style.animation = "bpxs2 1s linear";
			czhong3.style.opacity = "0";
		}, 26000);

	setTimeout(
		function ee9() {
			czhong3.style.opacity = "1";
			czhong3.style.top = "200px";
			czhong3.style.left = "300px";
			c222.style.animation = "hs2 1s linear";
			white3.style.animation = "bpxs2 1s linear";
			czuo1.style.opacity = "0";
		}, 26500);

	setTimeout(
		function ee10() {
			czuo1.style.opacity = "1";
			czuo1.style.top = "0px";
			czuo1.style.left = "600px";
			c2.style.animation = "hs 1s linear";
			white.style.animation = "bpxs 1s linear";
			cyou2.style.opacity = "0";
		}, 27000);


	setTimeout(
		function ee11() {
			cyou2.style.opacity = "1";
			cyou2.style.top = "200px";
			cyou2.style.left = "800px";
			c22.style.animation = "hs 1s linear";
			white2.style.animation = "bpxs 1s linear";
			czhong3.style.opacity = "0";
		}, 27500);

	setTimeout(
		function ee12() {
			czuo1.style.opacity = "0";
		}, 28000);

	setTimeout(
		function ee13() {
			cyou2.style.opacity = "0";
		}, 28500);

	setTimeout(
		function ff1() {
			f1.style.opacity = "1";
			f1.style.animation = "pyf 10s linear";

			f2.style.opacity = "1";
			f2.style.animation = "xzf1 20s ease-out,xzf2 13s ease-in";

			wzz.style.animation = "wzz 10s linear";
		}, 28600);

	setTimeout(
		function ff2() {
			f3.style.opacity = "1";
			f3.style.animation = "yf1 10s linear";

		}, 30000);

	setTimeout(
		function ff3() {
			f4.style.opacity = "1";
			f4.style.animation = "yf2 10s linear";

		}, 31000);

	setTimeout(
		function ff4() {
			overf.style.opacity = "1";
			overf.style.animation = "overf 30s linear";
		}, 36000);

	setTimeout(
		function g1() {
			wzz2.style.opacity = "1";
			wz1.style.animation = "fdtmwz1 3s linear";
			f2.style.opacity = "0";
			f3.style.opacity = "0";
			f4.style.opacity = "0";
		}, 41000);

	setTimeout(
		function g2() {
			wz2.style.opacity = "1";
			wz2.style.animation = "fdtmwz1 3s linear";
		}, 44000);

	setTimeout(
		function g3() {
			wz3.style.opacity = "1";
			wz3.style.animation = "fdtmwz1 3s linear";
		}, 47000);

	setTimeout(
		function g4() {
			wz4.style.opacity = "1";
			wz4.style.animation = "fdtmwz1 3s linear";
		}, 50000);

	setTimeout(
		function g5() {
			wz5.style.opacity = "1";
			wz5.style.animation = "fdtmwz1 3s linear";
		}, 53000);

	setTimeout(
		function g6() {
			wz6.style.opacity = "1";
			wz6.style.animation = "fdtmwz1 3s linear";
		}, 56000);

	setTimeout(
		function g7() {
			wz7.style.opacity = "1";
			wz7.style.animation = "fdtmwz1 3s linear";
		}, 59000);

	setTimeout(
		function g8() {
			overf.style.opacity = "0";
		}, 60000);
}
